require "rubygems"
require "twitter"

def verbinde
  Twitter.configure do |config|
    config.consumer_key = 'PI9G0QWxNfkKiBkgxIQFEg'
    config.consumer_secret = '83kCSIOBz1GKg7ewg7A2f7Wt0awaidCPHHn3iXB2I0I'
    config.oauth_token = '224323635-CYQEjsisDcT3Kfe6y1C57KWkc442TLYux9ICDjcn'
    config.oauth_token_secret = 'kBre9kcdZZUCDfOzXXX6wtGhYyU8u7qSArHHJnM3a4'
  end
  client = Twitter::Client.new
  return client
end

def suche(name)
  arr = Twitter::Search.new.containing("elenio_").per_page(10).fetch 
  return arr
end

def ausgabe()
  #search = Twitter::Search.new
  #search.containing("elenio_").fetch.each do |r|
  #puts "#{r.text}"
end


def fill()
  tweets=[]
  tweets << "ich finde twitter toll"
  tweets << "ruby ist auch spitze"
  tweets << "zu weihnachten habe ich tolle sachen bekommen"
  tweets << "sentiment analyse mit ruby funktioniert ganz einfach"
  tweets << "ich freue mich doll, wenn dortmund gewinnt"
  tweets << "schade, dass wir wieder uni haben"
  tweets << "heute habe ich schlechte milch getrunken"
  tweets << "ich finds doof, dass wir bald klausuren schreiben"       
  
  client = verbinde();
  tweets.each {|tweet| client.update(tweet)}
  
end

  
#fill()

