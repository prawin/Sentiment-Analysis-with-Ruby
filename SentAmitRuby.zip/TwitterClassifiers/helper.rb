def clean(phrase)
  phrase.gsub!(/\u00DF/,'ss')
  phrase.gsub!(/\t/,'')
  phrase.gsub!(/\u00E4/,'ae')
  phrase.gsub!(/\u00C4/,'ae')
  phrase.gsub!(/\u00FC/,'ue')
  phrase.gsub!(/\u00DC/,'ue')
  phrase.gsub!(/\u00F6/,'oe')
  phrase.gsub!(/\u00D6/,'oe')
  phrase.downcase!
end


$stop_words = %w{ich, mir, mein, meine, mich, meinen, wir, unser, unsere, 
                 unseres, unserer, unseren, du, dein, deine, deinen, deines, 
                 er, sein, seine, seines, seinen, sie, ihr, ihre, ihres, ihren, es, 
                 deren, dessen, ihnen, eure, euren, eures, eurer, welche, welcher, 
                 wer, wessen, dies, das, jenes, bin, bist, ist, sind, war, waren, 
                 warst, sein, gewesen, habe, haben, hat, hatte, hatten, tun, tut, 
                 tat, ein, eine, einer, eines, die, der, das, des, und, aber, wenn, 
                 oder, weil, als, waehrend, auf, bei, fuer, mit, ueber, unter, gegen, 
                 zwischen, in, im, durch, vor, bevor, nach, oberhalb, unterhalb, 
                 bis, von, hoch, runter, in, aus, an, ferner, dann, mal, hier, dort, 
                 was, wo, wann, warum, wie, alle, irgend, jemand, beide, jeder, mehr, 
                 meisten, andere, anderen, anderes, einige, einigen, einiger, solche, 
                 solcher, solchen, ja, nein, nicht, nur, selbst, selbe, selben, selber, 
                 so, dann, danach, auch, sehr, doch, weil, da aber ,alle ,allen ,alles ,
                 als ,also ,andere ,anderem ,anderer ,nderes ,anders ,auch ,auf ,aus ,
                 ausser ,ausserdem ,bei ,beide ,beiden ,beides ,beim ,bereits ,bestehen,
                 besteht ,bevor ,bin ,bis ,bloss ,brauchen ,braucht ,dabei ,dadurch ,
                 dagegen ,daher ,damit ,danach ,dann ,darf ,darueber ,darum ,darunter ,
                 das ,dass ,davon ,dazu ,dem ,den ,denn ,der ,des ,deshalb ,dessen ,die ,
                 dies ,diese ,diesem ,diesen ,dieser ,dieses ,doch ,dort ,duerfen ,durch ,
                 durfte ,durften ,ebenfalls ,ebenso ,ein ,eine ,einem ,einen ,einer ,
                 eines ,einige ,einiges ,einzig ,entweder ,erst ,erste ,ersten ,etwa ,
                 etwas ,falls ,fast ,ferner ,folgender ,folglich ,fuer ,ganz ,geben ,
                 gegen ,gehabt ,gekonnt ,gemaess ,getan ,gewesen ,gewollt ,geworden ,
                 gibt ,habe ,haben ,haette ,haetten ,hallo ,hat ,hatte ,hatten ,heraus ,
                 herein ,hier ,hin ,hinein ,inter ,ich ,ihm ,ihn ,ihnen ,ihr ,ihre ,ihrem ,
                 ihren ,ihres ,immer ,indem ,infolge ,innen ,innerhalb ,ins ,inzwischen ,
                 irgend ,irgendwas ,irgendwen ,irgendwer ,irgendwie ,irgendwo ,ist ,
                 jede ,jedem ,jeden ,jeder ,jedes ,jedoch ,jene ,enem ,jenen ,jener ,
                 jenes ,kann ,kein ,keine ,keinem ,keinen ,keiner ,keines ,koennen ,
                 koennte ,koennten ,konnte ,konnten ,kuenftig ,leer ,machen ,macht ,
                 machte ,achten ,man ,mehr ,mein ,meine ,meinen ,meinem ,meiner ,meist ,
                 meiste ,meisten ,mich ,mit ,moechte ,moechten ,muessen ,muessten ,muss ,
                 musste ,mussten ,nach ,nachdem ,nacher ,naemlich ,neben ,nein ,nicht ,
                 nichts ,noch ,nuetz ,nur ,nutzt ,obgleich ,obwohl ,oder ,ohne ,per ,
                 pro ,rund ,schon ,sehr ,seid ,sein ,seine ,seinem ,seinen ,einer ,seit ,
                 seitdem ,seither ,selber ,sich,sie ,siehe ,sind ,sobald ,solange ,solch ,
                 solche ,solchem ,solchen ,solcher ,solches ,soll ,sollen ,sollte ,sollten ,
                 somit ,sondern ,soweit ,sowie ,spaeter ,stets ,such ,ueber ,ums ,und ,uns ,
                 unser ,unsere ,unserem , unseren ,viel ,viele ,vollstaendig ,vom ,von ,
                 vor ,vorbei ,vorher ,vorueber ,waehrend ,waere ,waeren ,wann ,war ,waren ,
                 warum ,was ,wegen ,weil ,weiter ,weitere ,weiterem ,weiteren ,weiterer ,weiteres ,
                 weiterhin ,welche ,welchem ,welchen ,welcher ,welches ,wem ,wen ,wenigstens ,wenn ,
                 wenngleich ,wer ,werde ,werden ,weshalb ,wessen ,wie ,wiedre ,will,wir ,wird ,wodurch ,
                 wohin ,wollen ,wollte ,wollten ,worin ,wuerde ,wuerden ,wurde ,wurden ,zufolge ,zum ,
                 zusammen ,zur ,zwar ,zwischen
                 }




def clean_stopp(phrase)
  words = phrase.scan(/\w+/)
  key_words = words.select { |word| !$stop_words.include?(word) }
  satz = key_words.join(' ')
  return satz
end


satz = clean_stopp("das ist ein test")
