require 'rubygems'
require 'stemmer'
require 'classifier'
require 'yaml'
require_relative  'helper'
require_relative  'twitter_api'
require 'complex'



class TwitterClassifiers

  def loadTrainFiles
    @negativ = YAML::load_file('schlecht.yml')
    @positiv = YAML::load_file('gut.yml')
    @container = YAML::load_file('container.yml')
    @results = YAML::load_file('results.yml')
  end
  
  def trainBayesClassifier
    puts "Klassifizierung der Trainingsdatensaetze mit Bayes"
    @bayesianClassifier = Classifier::Bayes.new('positiv', 'negativ')
    @positiv.each{|phrase| @bayesianClassifier.train_positiv phrase }
    @negativ.each{|phrase| @bayesianClassifier.train_negativ phrase }
  end
  
  def trainLSIClassifier
    puts "Klassifizierung der Trainingsdatensaetze mit LSI"
    @lsiClassifier = Classifier::LSI.new(:auto_rebuild => false)
    @negativ.each{|n| @lsiClassifier.add_item(n, 'negativ') }
    @positiv.each{|p| @lsiClassifier.add_item(p, 'positiv') }
    @lsiClassifier.build_index
  end
  
  def initialize
  @bayesianClassifier=nil
  @lsiClassifier=nil
    loadTrainFiles
    trainBayesClassifier
    #trainLSIClassifier
  end
  
  def classify_twitter(arr, classifier)
    puts "Klassifizierung der reellen Twitterdaten"
    if(arr.size != 0)
      i = 1 #Zaehler
      p_i = 0 # positiv Zaehler
      arr.each do |r|
        clean(r.text)
        ausdruck_cleaned = clean_stopp(r.text)
        testing = @bayesianClassifier.classify ausdruck_cleaned if classifier == 'bayes'
        testing = @lsiClassifier.classify ausdruck if classifier == 'lsi'
        puts "tweet #{i}: #{r.text} : #{testing}"
        p_i += 1 if testing.downcase == 'positiv'
        i +=1
      end
      puts "\nAnzahl Nachrichten: #{arr.size}"
      puts "Es sind #{p_i} Nachrichten positiv und #{arr.size-p_i} negativ"
      puts "Das entspricht einem positiven Sentiment von: #{(p_i/arr.size).to_f*100}%"
    else
      puts 'Achtung, die Suche hatte keine treffer'
    end
  end   
  
  def classify_real(arr, classifier)
   puts "Klassifizierung der reellen Daten"
    if(arr.size != 0)
      i = 1 #Zaehler
      p_i = 0 # positiv Zaehler
      arr.each do |r|
        clean(r)
        ausdruck_cleaned = clean_stopp(r)
        testing = @bayesianClassifier.classify ausdruck_cleaned if classifier == 'bayes'
        testing = @lsiClassifier.classify ausdruck if classifier == 'lsi'
        puts "Nachricht #{i}: #{r} : #{testing}"
        p_i += 1 if testing.downcase == 'positiv'
        i +=1
      end
      puts "\nAnzahl Nachrichten: #{arr.size}"
      puts "Es sind #{p_i} Nachrichten positiv und #{arr.size-p_i} negativ"
      puts "Das entspricht einem positiven Sentiment von: #{(p_i/arr.size).to_f*100}%"
    else
      puts 'Achtung, der Container ist leer'
    end
  end
  
  
  def test(classifier)
    $i = 0 #korrekten Tests
    $zaehler = 0 #Durchlaeufe
    $fehlerart_1 = 0 #positiv als negativ 
    $fehlerart_2 = 0 #negativ als positiv
    if (@container.size == @results.size)
      @container.each{ |ausdruck|
        clean(ausdruck)
        ausdruck_cleaned = clean_stopp(ausdruck)
        $temp = (@bayesianClassifier.classify ausdruck_cleaned).downcase if classifier == 'bayes'
        $temp = (@lsiClassifier.classify ausdruck_cleaned).downcase if classifier == 'lsi'
        if $temp == @results[$zaehler]
          $i += 1
        elsif (@results[$zaehler]  == 'positiv')
          $fehlerart_1 += 1
        elsif (@results[$zaehler] == 'negativ')
          $fehlerart_2 += 1
        end
        p "#{$zaehler} : #{ausdruck} : #{$temp}"
        $zaehler += 1
      }
      
      puts "\nRichtigkeit: #{($i/$zaehler).to_f*100}%"
      puts "davon #{$fehlerart_2} Ausdruecke positiv und #{$fehlerart_1} Ausdruecke negativ falsch dargestellt"
    else 
      puts 'Achtung, die Anzahl der zu testenden Ausdruecken ist ungleich der Ergebnisse!'
    end
  end
end

time_train = Time.now
tc = TwitterClassifiers.new
time_after_train = Time.now
puts "Dauer Training: #{time_after_train-time_train}"
tc.test('bayes')
arr = suche("elenio_")
time_classify = Time.now
puts "Dauer Klassifizierung: #{time_classify-time_after_train}"
tc.classify_twitter(arr, 'bayes')
